import 'package:flutter/material.dart';

class LoginHal extends StatefulWidget {
  const LoginHal({Key? key}) : super(key: key);

  @override
  _LoginHalState createState() => _LoginHalState();
}

class _LoginHalState extends State<LoginHal> {
  TextEditingController emailController = new TextEditingController();
  TextEditingController nohpController = new TextEditingController();

  void loginFunction() {
    if (emailController.text.toString() == "indriazharipane95@gmail.com" &&
        nohpController.text.toString() == "082275719210") {
      Navigator.of(context)
          .pushNamedAndRemoveUntil('/beranda', (route) => false);
    } else if (emailController.text.toString() == "admin@gmail.com" &&
        nohpController.text.toString() == "0811") {
      Navigator.of(context)
          .pushNamedAndRemoveUntil('/beranda', (route) => false);
    } else {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: Text("Email atau No.Handphone salah"),
      ));
    }
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      width: MediaQuery.of(context).size.width,
      height: MediaQuery.of(context).size.height,
      child: Padding(
        padding: const EdgeInsets.all(15.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Center(
              child: Text(
                'LOGIN',
                style: TextStyle(
                  color: Colors.white,
                  fontWeight: FontWeight.bold,
                  fontFamily: 'Relano',
                  fontSize: 50.0,
                ),
              ),
            ),
            SizedBox(
              height: 65.0,
            ),
            TextField(
              controller: emailController,
              decoration: InputDecoration(
                focusedBorder: OutlineInputBorder(
                  borderSide: BorderSide(color: Colors.grey, width: 2.0),
                ),
                enabledBorder: OutlineInputBorder(
                  borderSide: BorderSide(color: Colors.grey, width: 2.0),
                ),
                hoverColor: Colors.transparent,
                fillColor: Colors.white,
                filled: true,
                hintText: "Email",
                hintStyle: TextStyle(
                  color: Colors.grey,
                ),
                prefixIcon: Icon(
                  Icons.email,
                  color: Colors.grey,
                ),
              ),
            ),
            SizedBox(
              height: 25.0,
            ),
            TextField(
              controller: nohpController,
              decoration: InputDecoration(
                focusedBorder: OutlineInputBorder(
                  borderSide: BorderSide(color: Colors.grey, width: 2.0),
                ),
                enabledBorder: OutlineInputBorder(
                  borderSide: BorderSide(color: Colors.grey, width: 2.0),
                ),
                fillColor: Colors.white,
                filled: true,
                hintText: "No.Handphone",
                hintStyle: TextStyle(
                  color: Colors.grey,
                ),
                prefixIcon: Icon(
                  Icons.phone_android,
                  color: Colors.grey,
                ),
              ),
            ),
            SizedBox(
              height: 20.0,
            ),
            Container(
              width: MediaQuery.of(context).size.width,
              child: Text(
                "Lupa Password?",
                textAlign: TextAlign.end,
                style: TextStyle(
                  decoration: TextDecoration.underline,
                  fontWeight: FontWeight.bold,
                  fontSize: 15.0,
                  color: Colors.white,
                ),
              ),
            ),
            SizedBox(
              height: 20.0,
            ),
            Center(
              child: MaterialButton(
                minWidth: 150.0,
                height: 45.0,
                color: Colors.green,
                onPressed: () {
                  loginFunction();
                },
                child: Text(
                  "LOGIN",
                  style: TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.bold,
                    fontSize: 20.0,
                  ),
                ),
              ),
            ),
            SizedBox(
              height: 20.0,
            ),
            Center(
              child: MaterialButton(
                minWidth: 150.0,
                height: 45.0,
                color: Colors.green,
                onPressed: () {
                  Navigator.pushNamed(context, '/registration');
                },
                child: Text(
                  "SIGN UP",
                  style: TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.bold,
                    fontSize: 20.0,
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class RegistrationHal extends StatefulWidget {
  RegistrationHal({Key? key}) : super(key: key);

  @override
  _RegistrationHalState createState() => _RegistrationHalState();
}

class _RegistrationHalState extends State<RegistrationHal> {
  @override
  Widget build(BuildContext context) {
    return Container(
      width: MediaQuery.of(context).size.width,
      height: MediaQuery.of(context).size.height,
      child: Padding(
        padding: const EdgeInsets.all(15.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Center(
              child: Text(
                'SIGN UP',
                style: TextStyle(
                  color: Colors.white,
                  fontWeight: FontWeight.bold,
                  fontFamily: 'Relano',
                  fontSize: 50.0,
                ),
              ),
            ),
            SizedBox(
              height: 65.0,
            ),
            TextField(
              decoration: InputDecoration(
                focusedBorder: OutlineInputBorder(
                  borderSide: BorderSide(color: Colors.grey, width: 2.0),
                ),
                enabledBorder: OutlineInputBorder(
                  borderSide: BorderSide(color: Colors.grey, width: 2.0),
                ),
                hoverColor: Colors.transparent,
                fillColor: Colors.white,
                filled: true,
                hintText: "Email",
                hintStyle: TextStyle(
                  color: Colors.grey,
                ),
                prefixIcon: Icon(
                  Icons.email,
                  color: Colors.grey,
                ),
              ),
            ),
            SizedBox(
              height: 25.0,
            ),
            TextField(
              decoration: InputDecoration(
                focusedBorder: OutlineInputBorder(
                  borderSide: BorderSide(color: Colors.grey, width: 2.0),
                ),
                enabledBorder: OutlineInputBorder(
                  borderSide: BorderSide(color: Colors.grey, width: 2.0),
                ),
                fillColor: Colors.white,
                filled: true,
                hintText: "No.Handphone",
                hintStyle: TextStyle(
                  color: Colors.grey,
                ),
                prefixIcon: Icon(
                  Icons.phone_android,
                  color: Colors.grey,
                ),
              ),
            ),
            SizedBox(
              height: 25.0,
            ),
            TextField(
              decoration: InputDecoration(
                focusedBorder: OutlineInputBorder(
                  borderSide: BorderSide(color: Colors.grey, width: 2.0),
                ),
                enabledBorder: OutlineInputBorder(
                  borderSide: BorderSide(color: Colors.grey, width: 2.0),
                ),
                fillColor: Colors.white,
                filled: true,
                hintText: "Nama Lengkap",
                hintStyle: TextStyle(
                  color: Colors.grey,
                ),
                prefixIcon: Icon(
                  Icons.person,
                  color: Colors.grey,
                ),
              ),
            ),
            SizedBox(
              height: 60.0,
            ),
            Center(
              child: MaterialButton(
                minWidth: 150.0,
                height: 45.0,
                color: Colors.green,
                onPressed: () {},
                child: Text(
                  "SIGN UP",
                  style: TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.bold,
                    fontSize: 20.0,
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
